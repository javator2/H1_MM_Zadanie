create function obnizka(x decimal, y decimal)
  returns decimal(10, 2)
  return round(x - x*(y/100),2);

