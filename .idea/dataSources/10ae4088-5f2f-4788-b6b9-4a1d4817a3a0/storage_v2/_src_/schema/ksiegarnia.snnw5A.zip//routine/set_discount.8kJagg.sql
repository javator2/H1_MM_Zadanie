create procedure set_discount(IN given_isbn char(17), IN discount int)
  Begin
 update books set price= round(price-price*(discount/100),2) where isbn=given_isbn;
end;

