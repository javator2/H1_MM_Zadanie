create trigger stock_out
  after UPDATE
  on books
  for each row
  begin
set @missing = 10 - new.on_stock;
if @missing > 0 then 
insert ignore into to_order values (new.title, @missing)
on duplicate key update missing = @missing;
end if;
end;

