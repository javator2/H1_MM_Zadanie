create trigger stock_ok
  after UPDATE
  on books
  for each row
  begin
if old.on_stock < 10 and new.on_stock >= 10 then
delete from to_order where title = old.title;
end if;
end;

