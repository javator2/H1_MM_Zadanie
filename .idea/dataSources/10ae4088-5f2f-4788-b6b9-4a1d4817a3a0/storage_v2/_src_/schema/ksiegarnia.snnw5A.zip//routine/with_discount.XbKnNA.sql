create procedure with_discount(IN x int, IN y int)
  begin
select title, price, round(price-price*(y/100),2) as po_obniżce from books where price = x;
end;

